# Import modules
import numpy as np


# Build the knapsack problem class
class Knapsack:
    # Initialize the class
    def __init__(self):
        # Initialize the maximum capacity of the knapsack
        self.maxCapacity = 0
        # Initialize the list of items available to the knapsack
        self.items = []

        # Initialize the data
        self.__initData()
    
    # Return the total number of items in the knapsack
    def __len__(self):
        return len(self.items)
    
    # Initialize the data
    def __initData(self):
        # Set the list of items (name, weight, value)
        self.items = [
            ("map", 9, 150),
            ("compass", 13, 35),
            ("water", 153, 200),
            ("sandwich", 50, 160),
            ("glucose", 15, 60),
            ("tin", 68, 45),
            ("banana", 27, 60),
            ("apple", 39, 40),
            ("cheese", 23, 30),
            ("beer", 52, 10),
            ("suntan cream", 11, 70),
            ("camera", 32, 30),
            ("t-shirt", 24, 15),
            ("trousers", 48, 10),
            ("umbrella", 73, 40),
            ("waterproof trousers", 42, 70),
            ("waterproof overclothes", 43, 75),
            ("note-case", 22, 80),
            ("sunglasses", 7, 20),
            ("towel", 18, 12),
            ("socks", 4, 50),
            ("book", 30, 10)
        ]
    
        # Set the maximum capacity of the knapsack
        self.maxCapacity = 400
    
    # Calcuate the total value of the items in the knapsack
    def getTotalValue(self, zeroOneList):
        # Calculates the value of the selected items in the list, while ignoring items that will cause the accumulating weight to exceed the maximum weight
        # zeroOneList: a list of 0/1 values corresponding to the list of the problem's items. '1' means that item was selected.
        totalWeight = totalValue = 0
        for i in range(len(zeroOneList)):
            item, weight, value = self.items[i]
            if totalWeight + weight <= self.maxCapacity:
                totalWeight += zeroOneList[i] * weight
                totalValue += zeroOneList[i] * value
        return totalValue
    
    # Prints the selected items in the list, while ignoring items that will cause the accumulating weight to exceed the maximum weight
    def printItems(self, zeroOneList):
        totalWeight = totalValue = 0
        for i in range(len(zeroOneList)):
            item, weight, value = self.items[i]
            if totalWeight + weight <= self.maxCapacity:
                if zeroOneList[i] > 0:
                    totalWeight += weight
                    totalValue += value
                    print("- Adding {}: weight = {}, value = {}, accumulated weight = {}, accumulated value = {}".format(item, weight, value, totalWeight, totalValue))
        print("- Total weight = {}, Total value = {}".format(totalWeight, totalValue))


## Test the class
# Create an instance of the knapsack problem
knapsack = Knapsack()

# Create a random list of 0/1 values
randomList = [int(np.random.randint(2)) for i in range(len(knapsack))]
print("Random list: {}".format(randomList))

# Print the selected items
knapsack.printItems(randomList)

# Get the total value of the selected items
print("Total value of the selected items: {}".format(knapsack.getTotalValue(randomList)))