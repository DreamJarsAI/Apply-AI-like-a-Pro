> Vector Storage Example uses
>> Semantic Search
>> 
>> Summarization of documents
>> 
>> Synthesis over Heterogeneous Data
>> 
>> Sub-question query
>> 
>> Joint QA query
>> 
>> Multi-step query
>> 
>>> Features: Used models from huggingface (instead of LlamaIndex default OpenAI LLMs) and ChromaVector database (instead of LlamaIndexes default)

> List storage example uses
>> Semantic Search
>> 
>> Summarization of documents
>> 
>> Synthesis over Heterogeneous Data
>>> Features: Used models from huggingface (instead of LlamaIndex default OpenAI LLMs) and ChromaVector database (instead of LlamaIndexes default)

> Keyword table example use
>> Compare and contrast
>>> Features: Used models from huggingface (instead of LlamaIndex default OpenAI LLMs), ChromaVector database (instead of LlamaIndexes default), demonstrate ComposableGraph (Build Keyword Table Index on top of vector indices!)

> Structured data examples
>> SQL
>> 
>> Pandas
