Refer to data video here: https://www.fns.usda.gov/snap/snap-retailer-authorization-video

