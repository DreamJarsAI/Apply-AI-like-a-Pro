# BERTopic_demo

demo of BERTopic, all rights go to them. 

For `BERTopic_hierachical_dynamic_topic_distributions.ipynb` data has can be found at https://www.kaggle.com/datasets/smid80/coronavirus-covid19-tweets/versions/18?resource=download


Data for the other notebooks are uploaded here, and are courtesy of the newsources extracted from `py-newscollector` package. All rights go to the original sources. 
