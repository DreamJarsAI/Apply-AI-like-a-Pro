# Import the TSP problem class
from tsp import TSPDataHandler

# Import the modified eaSimple function with elitisim
# Note: This function is written by: https://github.com/PacktPublishing/Hands-On-Genetic-Algorithms-with-Python-Second-Edition/blob/main/chapter_05/elitism.py
from elitism import eaSimpleWithElitism

# Import modules
from deap import base, tools, creator, algorithms
import numpy as np
import matplotlib.pyplot as plt
import random
import pickle
import array


# Create an instance of the TSP problem
url = "http://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp//bayg29.tsp.gz"
tsp_handler = TSPDataHandler(url)


# Load the distance matrix from the pickle file
with open('distance_matrix.pkl', 'rb') as f:
    distance_matrix = pickle.load(f)


# Define the problem contraints
ITEMS_LENGTH = len(distance_matrix)
POPULATION_SIZE = 300
P_CROSSOVER = 0.9
P_MUTATION = 0.1
MAX_GENERATIONS = 200
HALL_OF_FAME_SIZE = 15


# Define random seed
RANDOM_SEED = 42
random.seed(RANDOM_SEED)


# Create the fitness class
creator.create('FitnessMin', 
               base.Fitness, 
               weights=(-1.0,)) # -1.0 means we want to minimize the value


# Create the individual class
creator.create('Individual', 
               array.array, 
               typecode='i', # i means integer
               fitness=creator.FitnessMin)


# Register the random ordering operator
toolbox = base.Toolbox()
toolbox.register("randomOrder", random.sample, range(ITEMS_LENGTH), ITEMS_LENGTH)


# Register the individualCreator operator
toolbox.register('individualCreator', 
                 tools.initIterate, # Note that this is an iterator, not a repeater, because the individual is an array 
                 creator.Individual, 
                 toolbox.randomOrder)


# Register the populationCreator operator
toolbox.register('populationCreator', 
                 tools.initRepeat, 
                 list, 
                 toolbox.individualCreator)


# Define a function to evaluate the total value of the selected items
def evaluate(individual):
    return tsp_handler.calculate_tour_distance(individual),  # return a tuple


# Register the countOnes function
toolbox.register('evaluate', evaluate)


# Create the genetic operators
toolbox.register('select', tools.selTournament, tournsize=3)
toolbox.register('mate', tools.cxOrdered)
toolbox.register('mutate', tools.mutShuffleIndexes, indpb=1.0/ITEMS_LENGTH)


# Create the statistics object
stats = tools.Statistics(lambda ind: ind.fitness.values)


# Register the statistics object
stats.register('min', np.min)
stats.register('avg', np.mean)


# Create the hall of fame object
hof = tools.HallOfFame(HALL_OF_FAME_SIZE)


# Define the algorithm
population, logbook = eaSimpleWithElitism(
    toolbox.populationCreator(n=POPULATION_SIZE),
    toolbox,
    cxpb=P_CROSSOVER,
    mutpb=P_MUTATION,
    ngen=MAX_GENERATIONS,
    stats=stats,
    halloffame=hof,
    verbose=True
)


# Print the best ever individual
print("Best Ever Individual = ", hof.items[0])


# Return the min and mean values
minFitnessValues, meanFitnessValues = logbook.select("min", "avg")


# Plot the max and mean values
plt.plot(minFitnessValues, color='red')
plt.plot(meanFitnessValues, color='green')
plt.legend(('Min', 'Mean'), loc='lower right')
plt.xlabel('Generation')
plt.ylabel('Min / Average Fitness')
plt.title('Min and Mean Fitness over Generations')
plt.show()


# Draw the tour
tsp_handler.draw_tour(hof.items[0])
