import requests
import gzip
import pickle
from io import BytesIO
import random
import matplotlib.pyplot as plt

class TSPDataHandler:
    def __init__(self, url):
        self.url = url

        # Call the functions below to create the distance matrix
        self.city_data = self.parse_tsp_data(self.download_file())
        self.distance_matrix = self.create_distance_matrix(self.city_data)

        # Save the distance matrix in a pickle file
        with open('distance_matrix.pkl', 'wb') as f:
            pickle.dump(self.distance_matrix, f)
    
    # Define a function to download and decompress the .tsp.gz file
    def download_file(self):
        response = requests.get(self.url)
        if response.status_code == 200:
            # Decompress gzip file in memory
            compressed_file = BytesIO(response.content)
            decompressed_file = gzip.GzipFile(fileobj=compressed_file)
            return decompressed_file.read().decode('utf-8')
        else:
            raise Exception("Failed to download the file, status code: {}".format(response.status_code))
    
    # Define a function to parse the .tsp data
    def parse_tsp_data(self, tsp_data):
        lines = tsp_data.splitlines()
        city_data = []
        start_parsing = False
        for line in lines:
            if line.strip() == "DISPLAY_DATA_SECTION":
                start_parsing = True
                continue
            elif line.strip() == "EOF":
                break
            if start_parsing:
                parts = line.split()
                city_id = int(parts[0]) - 1 # city IDs start from 1, and we want them to start from 0
                x_coord = float(parts[1])
                y_coord = float(parts[2])
                city_data.append((city_id, x_coord, y_coord))
        return city_data
    
    # Define a function to use the pased data to create a matrix of distances between any two cities
    def create_distance_matrix(self, city_data):
        num_cities = len(city_data)
        distance_matrix = [[0] * num_cities for _ in range(num_cities)]
        for i in range(num_cities):
            for j in range(i + 1, num_cities):
                city1 = city_data[i]
                city2 = city_data[j]
                distance = self.calculate_distance(city1[1], city1[2], city2[1], city2[2])
                distance_matrix[i][j] = distance
                distance_matrix[j][i] = distance
        return distance_matrix
    
    # Define a function to calcuate the distance between two cities
    def calculate_distance(self, x1, y1, x2, y2):
        return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

    # Define a function to calculate the total distance of the tour
    # Note: The tour is represented as a list of city IDs
    # Note: tour[(i + 1) % len(tour)] is the next city in the tour, and it loops back to the first city
    def calculate_tour_distance(self, tour):
        distance = 0
        for i in range(len(tour)):
            city1 = tour[i]
            city2 = tour[(i + 1) % len(tour)]
            distance += self.distance_matrix[city1][city2]
        return distance
    
    # Define a function to draw the randomly generated tour in a map by connecting the cities with lines
    # Note: connect the last two cities in the tour with a line; add the city ids to the tour
    def draw_tour(self, tour):
        x_coords = [self.city_data[i][1] for i in tour]
        y_coords = [self.city_data[i][2] for i in tour]
        x_coords.append(self.city_data[tour[0]][1])
        y_coords.append(self.city_data[tour[0]][2])
        plt.plot(x_coords, y_coords, 'o-', markersize=3)
        plt.show()

# # Example usage:
# url = "http://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/tsp//bayg29.tsp.gz"
# tsp_handler = TSPDataHandler(url)

# # Load the distance matrix from the pickle file
# with open('distance_matrix.pkl', 'rb') as f:
#     distance_matrix = pickle.load(f)

# # Print the distance matrix with fixed number of rows and columns
# print("Distance matrix:")
# for i in range(len(distance_matrix)):
#     print(distance_matrix[i])

# # Generate a random tour by shuffling the list of cities
# tour = list(range(len(distance_matrix)))
# random.shuffle(tour)
# print("Random tour:", tour)

# # Calculate the tour distance
# print("Tour distance:", tsp_handler.calculate_tour_distance(tour))

# # Draw the tour
# tsp_handler.draw_tour(tour)
